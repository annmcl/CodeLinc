/*
start = 2
for (i = start; i < start + 9; i++) {
    document.getElementsByTagName("a")[i].innerHTML="hello"
}
*/